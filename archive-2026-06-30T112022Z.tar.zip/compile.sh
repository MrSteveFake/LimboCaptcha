#!/bin/bash

echo "==================================="
echo "Сборка LimboCaptcha (без Gradle)"
echo "==================================="

if ! command -v javac &> /dev/null; then
    echo "Ошибка: JDK не найден!"
    exit 1
fi

mkdir -p build/classes
mkdir -p build/merged

echo "Очистка предыдущей сборки..."
rm -rf build/classes/* build/merged/* build/*.jar

echo ""
echo "Компиляция Java файлов..."
find src -name "*.java" > sources.txt

CLASSPATH=""
for jar in libs/*.jar; do
    if [ -f "$jar" ]; then
        CLASSPATH="$CLASSPATH:$jar"
    fi
done

javac -d build/classes -cp "${CLASSPATH#:}" @sources.txt
rm sources.txt

echo ""
echo "Копирование ресурсов..."
cp -r resources/* build/classes/

echo ""
echo "Создание JAR файла..."
cd build/classes
jar cf ../temp.jar *
cd ../..

echo ""
echo "Объединение с зависимостями..."
cd build/merged

for jar in ../../libs/*.jar; do
    if [ -f "$jar" ]; then
        echo "  Распаковка: $(basename $jar)"
        jar xf "$jar"
    fi
done

jar xf ../temp.jar
rm -rf META-INF
rm -rf module-info.class

echo ""
echo "Создание финального JAR..."
jar cf ../LimboCaptcha.jar *
cd ../..

rm -rf build/classes build/merged build/temp.jar

echo ""
echo "==================================="
echo "Сборка завершена!"
echo "Файл: build/LimboCaptcha.jar"
echo "==================================="