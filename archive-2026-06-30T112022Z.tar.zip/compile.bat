@echo off
chcp 65001 >nul
echo ===================================
echo Сборка LimboCaptcha (без Gradle)
echo ===================================

javac -version >nul 2>&1
if errorlevel 1 (
    echo Ошибка: JDK не найден!
    pause
    exit /b 1
)

if not exist "build" mkdir build
if not exist "build\classes" mkdir build\classes
if not exist "build\merged" mkdir build\merged

echo Очистка предыдущей сборки...
if exist "build\classes\*" del /Q "build\classes\*"
if exist "build\merged\*" del /Q "build\merged\*"
if exist "build\*.jar" del /Q "build\*.jar"

echo Сбор classpath...
setlocal enabledelayedexpansion
set CLASSPATH=
for %%f in (libs\*.jar) do (
    set CLASSPATH=!CLASSPATH!;%%f
)

echo Компиляция Java файлов...
dir /s /B src\*.java > sources.txt
javac -d build\classes -cp "!CLASSPATH!" @sources.txt
del sources.txt
endlocal

echo Копирование ресурсов...
xcopy /E /I /Y resources build\classes >nul

echo Создание JAR файла...
cd build\classes
jar cf ..\temp.jar *
cd ..\..

echo Объединение с зависимостями...
cd build\merged

for %%f in (..\..\libs\*.jar) do (
    echo   Распаковка: %%~nxf
    jar xf "%%f"
)

jar xf ..\temp.jar

if exist "META-INF" rmdir /S /Q "META-INF"
if exist "module-info.class" del "module-info.class"

echo Создание финального JAR...
jar cf ..\LimboCaptcha.jar *
cd ..\..

rmdir /S /Q build\classes
rmdir /S /Q build\merged
del build\temp.jar

echo.
echo ===================================
echo Сборка завершена!
echo Файл: build\LimboCaptcha.jar
echo ===================================
pause