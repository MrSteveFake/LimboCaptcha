# LimboCaptcha

Плагин для Velocity 3.4.0 с Google reCAPTCHA v2 проверкой.

## Требования
- Velocity 3.4.0+
- Java 17+

## Установка
1. Скачайте JAR из Actions/Releases
2. Поместите в папку `plugins/`
3. Настройте `config.yml`
4. Перезапустите сервер

## Сборка
```bash
# Linux/Mac
chmod +x compile.sh && ./compile.sh

# Windows
compile.bat